# Empty
An almost empty project ready for new visual novels
